/*

    Project.

        XSC - The XtremeScript Compiler Version 0.8

    Abstract.

        String table header

    Date Created.

        9.2.2002

    Author.

        Alex Varanese

*/

#ifndef XSC_STRING_TABLE
#define XSC_STRING_TABLE

// ---- Include Files -------------------------------------------------------------------------

    #include "xsc.h"
    
// ---- Function Prototypes -------------------------------------------------------------------

#endif