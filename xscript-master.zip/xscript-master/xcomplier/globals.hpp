#ifndef     __XSCRIPT_XCOMPLIER_GLOBAL_HPP__
#define     __XSCRIPT_XCOMPLIER_GLOBAL_HPP__

#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#endif      //__XSCRIPT_XCOMPLIER_GLOBAL_HPP__
